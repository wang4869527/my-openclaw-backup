# MEMORY.md - Long-Term Memory

_This file stores curated memories, decisions, and insights worth keeping._

## Initial Setup

- **2026-03-24**: Workspace initialized. OpenClaw gateway restarted, configuration updated to show free models only in dropdown.
- **Persona**: Nex - Embedded AI assistant, concise, practical, professional ⚡
- **2026-03-25**: Proactive Agent v3.1.0 onboarding completed.
  - User X confirmed: name, timezone (GMT+8), communication style (direct), goals (explore interests, plan, make money), vision (family happiness), productivity peaks (morning/evening), async preference.
  - Context updated in USER.md: full-house customization designer, wife and son, serious personality.
  - SOUL.md adjusted: professional, precise, no fluff.
  - Protocols active: WAL, Working Buffer, Compaction Recovery, Autonomous Crons.

## Installed Skills

- **skill-vetter** v1.0.0 - Security vetting tool
- **self-improving-agent** v3.0.6 (@pskoett, 301k downloads) - Continuous learning system
- **agent-browser** v0.2.0 (@thesethrose, 167k downloads) - Headless browser automation
  - Chrome for Testing manually downloaded to `C:\chrome-for-testing\chrome-win64\`
  - Environment variable: `AGENT_BROWSER_EXECUTABLE_PATH` set to Chrome binary
  - Skill installed with `--force` after reviewing SKILL.md (no malicious code detected)
- **proactive-agent** v3.1.0 (@halthelobster, 120k downloads) - Proactive agent architecture
  - Deployed assets: ONBOARDING.md, HEARTBEAT.md (not overriding existing AGENTS.md, USER.md, SOUL.md)
  - Protocols: WAL, Working Buffer, Compaction Recovery, Autonomous Crons

## Preferences

- **ClawHub 搜索设置**: 查找应用时，不要勾选 "Hide suspicious"（隐藏可疑）选项，以查看完整技能列表，包括所有评分和选项。
- **技能安装策略**: 优先安装高下载量、高评分的官方或知名作者技能。安装前使用 skill-vetter 进行安全审查。
- **自我改进**: 已配置 self-improving-agent v3.0.6，使用 `.learnings/` Markdown 格式记录学习。
- **浏览器自动化**: 使用 agent-browser，需确保 Chrome for Testing 路径配置正确。

## Important Context

_Keep track of important people, projects, and recurring tasks here._

---

_This file is updated periodically during heartbeat checks and significant events._
